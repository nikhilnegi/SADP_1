package com.sapient.sadp2;

import java.io.Serializable;

public class Department implements Serializable{

	int deptId;
	String deptName;
	int leadId;
	
	
	
	public Department(int deptId, String deptName, int leadId) {
		
		this.deptId = deptId;
		this.deptName = deptName;
		this.leadId = leadId;
		
	}
	
	public int getDeptId() {
		return deptId;
	}
	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	
	public int getLeadId() {
		return leadId;
	}
	public void setLeadId(int leadId) {
		this.leadId = leadId;
	}
	@Override
	public String toString() {
		return "Department [deptId=" + deptId + ", deptName=" + deptName + ", lead=" + leadId + "]";
	}
	
	
}
