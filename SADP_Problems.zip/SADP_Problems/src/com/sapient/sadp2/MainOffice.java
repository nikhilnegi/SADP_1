package com.sapient.sadp2;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.*;

public class MainOffice {

	public static void main(String[] args) {
		
		Employee e1 = new Employee(1,"Mr.A","Z","Address1",200000,new Department(1,"Dept1",1));
		Employee e2 = new Employee(2,"Mr.B","Y","Address2",250000,new Department(2,"Dept2",2));
		Employee e3 = new Employee(3,"Mr.C","X","Address3",280000,new Department(3,"Dept3",3));
		
		List<Employee> empList = new ArrayList();
		empList.add(e1);
		empList.add(e2);
		empList.add(e3);
		
		for(Employee e : empList)
		{
		Employee emp = null;
		
		try {
			System.out.println("Writing into a file (Serialization)");
			FileOutputStream fileOut = new FileOutputStream("./employee1.txt");
			ObjectOutputStream out = new ObjectOutputStream(fileOut);
			out.writeObject(e);
			out.close();
			fileOut.close();
			System.out.printf("Serialized data is saved in ./employee.txt file");
			System.out.println("\n");
			System.out.println("Reading from the file created (Deserialization)");
			FileInputStream fileIn = new FileInputStream("./employee1.txt");
			ObjectInputStream in = new ObjectInputStream(fileIn);
			emp = (Employee) in.readObject();
			in.close();
			fileIn.close();
	}
		catch(IOException i){ i.printStackTrace();}
		catch (ClassNotFoundException c) {
			System.out.println("Employee class not found");
			c.printStackTrace();
			return;
		}
		
		System.out.println(emp);
		}

	}

}
