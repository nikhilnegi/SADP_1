package com.sapient.sadp;

import java.util.*;

public class TestCoordinates {

	public static void main(String[] args) {
		
		List<Coordinate> cl = new ArrayList();
		
		cl.add(new Coordinate(0,0));
		cl.add(new Coordinate(-1,1));
		cl.add(new Coordinate(-2,4));
		cl.add(new Coordinate(-2,-3));
		cl.add(new Coordinate(-10,2));
		cl.add(new Coordinate(5,-1));
		cl.add(new Coordinate(2,4));
		cl.add(new Coordinate(1,0));
		cl.add(new Coordinate(10,3));
		
		//Print each coordinate using lambda expression
		cl.forEach(coordinate -> System.out.println(coordinate));
		
		//Calculate sum of X coordinates using mapToInt and reduce, print each X coordinate and final sum using 1 statement.
		System.out.println(cl.stream().mapToInt(Coordinate::getX) 
		 				.peek(System.out::println) 
		 				.reduce(0, (x1, x2) -> x1 + x2)); 
		
		//Calculate sum of all Y coordinates using sum()
		System.out.println("Sum of y cords :"+ cl.stream() 
		 		.mapToInt(Coordinate::getY) 
		 		.sum() 
		 		); 
		
		
		//Filter all coordinates with positive X and Y coordinates, print them
		cl.stream() 
		 		.filter(coordinate -> coordinate.getX() >= 0 ) 
		 		.filter(coordinate -> coordinate.getY() >= 0 ) 
		 		.forEach(System.out::println); 


		


	}

}
